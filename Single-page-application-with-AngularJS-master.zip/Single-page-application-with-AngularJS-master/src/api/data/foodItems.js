'use strict';

var foodItems = [
  { name: 'Beef' },
  { name: 'Onion' },
  { name: 'Pepper' },
  { name: 'Flour' },
  { name: 'Water'},
  { name: 'Baking Powder'},
  { name: 'Salt'},
  { name: 'Carrot'},
  { name: 'Cabbage'},
  { name: 'Sesame Seed Oil'},
  { name: 'Rice Wine Vinegar'},
  { name: 'Egg'},
  { name: 'Stones'},
  { name: 'Bread'},
  { name: 'Cheese'},
  { name: 'Butter'},
  { name: 'Lemons'},
  { name: 'Sugar'},
  { name: 'Steak'}
];

module.exports = foodItems;
