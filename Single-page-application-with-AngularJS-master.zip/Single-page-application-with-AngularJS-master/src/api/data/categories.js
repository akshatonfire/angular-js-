'use strict';

var categories = [
  { name: 'Appetizer/Snack'},
  { name: 'Beverage'},
  { name: 'Dessert'},
  { name: 'Entree'},
  { name: 'Salad'},
  { name: 'Side Dish'},
  { name: 'Soup'},
  { name: 'Other'}
];

module.exports = categories;
